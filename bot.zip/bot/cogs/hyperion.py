from __main__ import send_cmd_help
from discord.ext import commands
from cogs.utils import checks
from cogs.utils.dataIO import dataIO
from cogs.utils import chat_formatting
import discord
import inspect
import subprocess
import sys
import asyncio


class Hyperion:
    """Hyperion's Selfbot commands."""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(pass_context=True)
    async def perms(self, ctx):
        """Gets permissions for the user in the specified channel."""
        user = ctx.message.author
        channel = ctx.message.channel
        machine_permissions = inspect.getmembers(user.permissions_in(channel))
        human_permissions = {}
        for i in machine_permissions:
            if i[1] is True or i[1] is False:
                human_permissions[i[0]] = i[1]
        human_readable_permissions = ""
        for i in sorted(human_permissions):
            if human_permissions[i]:
                human_readable_permissions += "\n+ " + i
            else:
                human_readable_permissions += "\n- " + i
        human_readable_permissions2 = '```diff' + human_readable_permissions
        human_readable_permissions3 = human_readable_permissions2 + '```'
        old_msg = await self.bot.say(human_readable_permissions3)



    # called by listener
    async def shrug(self, message):
        user = message.author
        msg = message.content.lower()
        channel = message.channel
        
        if msg == "sh":
            await self.bot.edit_message(message, "¯\_(ツ)_/¯")

    # called by listener
    async def mfw(self, message):
        user = message.author
        msg = message.content.lower()
        channel = message.channel
        
        if msg == "mfw":
            await self.bot.edit_message(message, "**My Fucking World.**")

    # called by listener
    async def facedesk(self, message):
        user = message.author
        msg = message.content.lower()
        channel = message.channel
        
        if msg == "facedesk":
            await self.bot.edit_message(message, "https://giphy.com/gifs/to-aru-kagaku-no-railgun-JRMvrNMKfjqmI")

    # called by listener
    async def selfping(self, message):
        user = message.author
        msg = message.content.lower()
        channel = message.channel

        if msg == "selfping":
            await self.bot.edit_message(message, "Selfbot is responding.")

    # called by listener
    async def tableflip(self, message):
        user = message.author
        msg = message.content.lower()
        channel = message.channel

        if msg == "tb":
            await self.bot.edit_message(message, "(╯°□°）╯︵ ┻━┻")

    # called by listener
    async def wat(self, message):
        user = message.author
        msg = message.content.lower()
        channel = message.channel

        if msg == "wat":
            await self.bot.edit_message(message, "ಠ_ಠ")

    async def lenny(self, message):
        user = message.author
        msg = message.content.lower()
        channel = message.channel

        if msg == "lenny":
            await self.bot.edit_message(message, "( ͡° ͜ʖ ͡°)")

    # called by listener
    async def triggered(self, message):
        user = message.author
        msg = message.content.lower()
        channel = message.channel

        if msg == "triggered":
            await self.bot.edit_message(message, "https://giphy.com/gifs/ZEVc9uplCUJFu")

            
def setup(bot):
 n = Hyperion(bot)
 bot.add_listener(n.shrug, "on_message")
 bot.add_listener(n.mfw, "on_message")
 bot.add_listener(n.facedesk, "on_message")
 bot.add_listener(n.selfping, "on_message")
 bot.add_listener(n.tableflip, "on_message")
 bot.add_listener(n.wat, "on_message")
 bot.add_listener(n.triggered, "on_message")
 bot.add_listener(n.lenny, "on_message")
 bot.add_cog(n)

