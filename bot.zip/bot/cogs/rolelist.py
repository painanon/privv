import discord
import asyncio
from discord.ext import commands
from typing import List
from .utils import checks


class Rolelist:
    """List server roles"""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(pass_context=True)
    async def rolelist(self, ctx):
        server = ctx.message.server
        await self.bot.say("""```css\n[{}]```""".format('] - ['.join([role_hierarchy.name for role_hierarchy in server.role_hierarchy if not role_hierarchy.is_everyone])))

    @commands.command(pass_context=True)
    async def chanlist(self, ctx):
        """List server roles"""
        channels = ctx.message.author.server.channels
        data = "```css\n"
        yea = '\n'
        th1 = '['
        th2 = ']'
        for channel in channels:
            if str(channel.type) != 'voice':
                data += th1 + channel.name + th2
                data += " "
        data += "```"
        await self.bot.say(data)
    @commands.command(no_pm=True, pass_context=True)
    async def rolemembers (self, ctx, role: discord.Role):
        server = ctx.message.server
        rmembers = self._get_users_with_role(server, role)
        data = "```css\n"
        yea = '\n'
        th1 = '['
        th2 = ']'
        pound = '#'
        for user in rmembers:
            data += th1 + user.name + pound + user.discriminator + th2
            data += " "
        data += "```"
        if len(data) >= 1999:
            await self.bot.say("Over 2000 characters. Sorry")
        else:
            await self.bot.say(data)
            
    @commands.command(pass_context=True)
    async def invlist (self, ctx):
        server = ctx.message.server
        invlist = self.bot.invites_from(server)
        await self.bot.say(invlist.url)

    def _member_has_role(self, member: discord.Member, role: discord.Role):
        return role in member.roles

    def _get_users_with_role(self, server: discord.Server,
                             role: discord.Role) -> List[discord.User]:
        roled = []
        for member in server.members:
            if self._member_has_role(member, role):
                roled.append(member)
        return roled

def setup(bot):
    bot.add_cog(Rolelist(bot))
