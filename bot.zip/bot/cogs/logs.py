import discord
from discord.ext import commands
from random import choice as rndchoice
from .utils.dataIO import fileIO
from .utils import checks
import os
import asyncio

defaults = [
    "172395749814960134",] 
TIMESTAMP_FORMAT = '%Y-%m-%d %X'  # YYYY-MM-DD HH:MM:SS

class WillyLogs:
    def __init__(self, bot):
        self.bot = bot
        self.users = fileIO("data/logs/users.json", "load")
    def save_users(self):
        fileIO("data/logs/users.json", 'save', self.users)

    @commands.group(no_pms=True, pass_context=True)
    @checks.serverowner_or_permissions(administrator=True)
    async def mine(self, ctx):
        await self.bot.say("#!mine")
        await asyncio.sleep(315)
        await self.bot.say("a&mine")

    @commands.group(no_pms=True, pass_context=True)
    @checks.serverowner_or_permissions(administrator=True)
    async def forage(self, ctx):
        await self.bot.say("#!forage")
        await asyncio.sleep(315)
        await self.bot.say("a&forage")

    @commands.group(no_pms=True, pass_context=True)
    @checks.serverowner_or_permissions(administrator=True)
    async def fish(self, ctx):
        await self.bot.say("#!fish")
        await asyncio.sleep(315)
        await self.bot.say("a&fish")

    @commands.group(no_pms=True, pass_context=True)
    @checks.serverowner_or_permissions(administrator=True)
    async def chop(self, ctx):
        await self.bot.say("#!chop")
        await asyncio.sleep(315)
        await self.bot.say("a&chop")


def check_folders():
    if not os.path.exists("data/logs"):
        print("Creating data/logs folder...")
        os.makedirs("data/logs")

def check_files():
    f = "data/logs/users.json"
    if not fileIO(f, "check"):
        print("Creating empty users.json...")
        fileIO(f, "save", defaults)

def setup(bot):
    check_folders()
    check_files()
    n = WillyLogs(bot)
    bot.add_cog(n)
