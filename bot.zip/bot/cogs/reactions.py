from discord.ext import commands
import random
import discord

class Reactions:
    def __init__(self, bot):
        self.bot = bot


    @commands.command(pass_context=True)
    async def big(self, ctx, *, letters):
        letters.split()
        msg = ''
        for x in letters:
            if x != ' ':
                msg += ':regional_indicator_' + x + ': '
            else:
                msg += ' '
        await self.bot.say(msg)









def setup(bot):
    n = Reactions(bot)
    bot.add_cog(n)
