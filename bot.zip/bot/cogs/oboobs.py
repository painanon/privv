import discord
from discord.ext import commands
from .utils.dataIO import fileIO
from .utils import checks
from __main__ import send_cmd_help
# Sys
import aiohttp
import random
from random import choice
import os
import sys

DIR_DATA = "data/oboobs"
SETTINGS = DIR_DATA+"/settings.json"

#API info:
#example: "/boobs/10/20/rank/" - get 20 boobs elements, start from 10th ordered by rank; noise: "/noise/{count=1; sql limit}/", 
#example: "/noise/50/" - get 50 random noise elements; model search: "/boobs/model/{model; sql ilike}/", 
#example: "/boobs/model/something/" - get all boobs elements, where model name contains "something", ordered by id; author search: "/boobs/author/{author; sql ilike}/", 
#example: "/boobs/author/something/" - get all boobs elements, where author name contains "something", ordered by id; get boobs by id: "/boobs/get/{id=0}/", 
#example: "/boobs/get/6202/" - get boobs element with id 6202; get boobs count: "/boobs/count/"; get noise count: "/noise/count/"; vote for boobs: "/boobs/vote/{id=0}/{operation=plus;[plus,minus]}/", 
#example: "/boobs/vote/6202/minus/" - negative vote for boobs with id 6202; vote for noise: "/noise/vote/{id=0}/{operation=plus;[plus,minus]}/", 
#example: "/noise/vote/57/minus/" - negative vote for noise with id 57;

#example: "/butts/10/20/rank/" - get 20 butts elements, start from 10th ordered by rank; noise: "/noise/{count=1; sql limit}/", 
#example: "/noise/50/" - get 50 random noise elements; model search: "/butts/model/{model; sql ilike}/", 
#example: "/butts/model/something/" - get all butts elements, where model name contains "something", ordered by id; author search: "/butts/author/{author; sql ilike}/", 
#example: "/butts/author/something/" - get all butts elements, where author name contains "something", ordered by id; get butts by id: "/butts/get/{id=0}/", 
#example: "/butts/get/6202/" - get butts element with id 6202; get butts count: "/butts/count/"; get noise count: "/noise/count/"; vote for butts: "/butts/vote/{id=0}/{operation=plus;[plus,minus]}/", 
#example: "/butts/vote/6202/minus/" - negative vote for butts with id 6202; vote for noise: "/noise/vote/{id=0}/{operation=plus;[plus,minus]}/", 
#example: "/noise/vote/57/minus/" - negative vote for noise with id 57;

class oboobs:
    """The oboobs/obutts.ru NSFW pictures of nature cog.
    https://github.com/Canule/Mash-Cogs
    """

    def __init__(self, bot):
        self.bot = bot
        self.settings = fileIO(SETTINGS, "load")

    @commands.group(name="oboobs", pass_context=True)
    async def _oboobs(self, ctx):
        """The oboobs/obutts.ru pictures of nature cog."""        
        if ctx.invoked_subcommand is None:
            await send_cmd_help(ctx)
            return

    # Boobs
    @commands.command(pass_context=True, no_pm=False)
    async def boobs(self, ctx):
        """Shows some boobs."""
        author = ctx.message.author
        nsfwChan = False
        for a in self.settings["nsfw_channels"]:
            if a == ctx.message.channel.id:
                nsfwChan = True
                break
        try:
            rdm = random.randint(0, 10138)      
            search = ("http://api.oboobs.ru/boobs/{}".format(rdm))
            async with aiohttp.get(search) as r:
                result = await r.json()
                boob = random.choice(result)
                boob = "http://media.oboobs.ru/{}".format(boob["preview"])
        except Exception as e:
            await self.bot.say("{} ` Error getting results.`".format(author.mention))
            return
        if not nsfwChan:
            await self.bot.say("{}".format(boob))
        else:
            await self.bot.send_message(ctx.message.author, "{}".format(boob))
            if self.settings["nsfw_msg"]:
                await self.bot.say("{}` nsfw content is not allowed in this channel, instead I have send you a DM.`".format(author.mention))

    # Ass
    @commands.command(pass_context=True, no_pm=False)
    async def ass(self, ctx):
        """Shows some ass."""
        author = ctx.message.author
        nsfwChan = False
        for a in self.settings["nsfw_channels"]:
            if a == ctx.message.channel.id:
                nsfwChan = True
                break
        try:
            rdm = random.randint(0, 4131)        
            search = ("http://api.obutts.ru/butts/{}".format(rdm))
            async with aiohttp.get(search) as r:
                result = await r.json()
                ass = random.choice(result)
                ass = "http://media.obutts.ru/{}".format(ass["preview"])
        except Exception as e:
            await self.bot.say("{} ` Error getting results.`".format(author.mention))
            return
        if not nsfwChan:
            await self.bot.say("{}".format(ass))
        else:
            await self.bot.send_message(ctx.message.author, "{}".format(ass))
            if self.settings["nsfw_msg"]:
                await self.bot.say("{}` nsfw content is not allowed in this channel, instead I have send you a DM.`".format(author.mention))

    @checks.admin_or_permissions(manage_server=True)
    @_oboobs.command(pass_context=True, no_pm=False)
    async def nsfw(self, ctx):
        """Toggle oboobs nswf for this channel on/off.
        Admin/owner restricted."""
        user= ctx.message.author
        nsfwChan = None
        # Reset nsfw.
        for a in self.settings["nsfw_channels"]:
            if a == ctx.message.channel.id:
                nsfwChan = True
                self.settings["nsfw_channels"].remove(a)
                await self.bot.say("{} ` nsfw ON`".format(user.mention))
                break
        # Set nsfw.
        if not nsfwChan:
            if ctx.message.channel not in self.settings["nsfw_channels"]:
                self.settings["nsfw_channels"].append(ctx.message.channel.id)
                await self.bot.say("{} ` nsfw OFF`".format(user.mention))
        fileIO(SETTINGS, "save", self.settings)
        
    @checks.admin_or_permissions(manage_server=True)
    @_oboobs.command(pass_context=True, no_pm=False)
    async def togglemsg(self, ctx):
        """Enable/Disable the oboobs nswf not allowed message
        Admin/owner restricted."""
        user= ctx.message.author
        # Toggle
        if self.settings["nsfw_msg"]:
            self.settings["nsfw_msg"] = False
            await self.bot.say("{} ` DM nsfw channel msg is now: Disabled.`".format(user.mention))
        elif not self.settings["nsfw_msg"]:
            self.settings["nsfw_msg"] = True
            await self.bot.say("{} ` DM nsfw channel msg is now: Enabled.`".format(user.mention))
        fileIO(SETTINGS, "save", self.settings)

    @commands.command(pass_context=True, no_pm=False)
    async def yomama(self, ctx):
        """Yo Momma"""
        author = ctx.message.author
        await self.bot.say(random.choice(["Yo mama is so fat that her bellybutton gets home 15 minutes before she does.", "Yo mama is so fat that when she was diagnosed with a flesh-eating disease, the doctor gave her ten years to live.", "Yo mama is so fat that the National Weather Service names each one of her farts.", "Yo mama is so fat that when she wears a yellow raincoat, people yell 'taxi.'", "Yo mama is so fat and dumb that the only reason she opened her email was because she heard it contained spam.", "Yo mama is so fat she threw on a sheet for Halloween and went as Antarctica.", "Yo mama is so fat that she looked up cheat codes for Wii Fit", "Yo mama is so fat that the only exercise she gets is when she chases the ice cream truck.", "Yo mama is so fat that she sat on a dollar and squeezed a booger out George Washington's nose.", "Yo mama is so fat that when she gets in an elevator, it has to go down.", "Yo mama is so fat that when her beeper goes off, people think she's backing up.", "Yo mama is so fat that she has to iron her pants on the driveway.", "Yo mama is so fat that she left the house in high heels and came back wearing flip flops.", "Yo mama is so fat that people jog around her for exercise.", "Yo mama is so fat that she was floating in the ocean and Spain claimed her for the New World.", "Yo mama is so fat that when she walked in front of the TV, I missed 3 seasons of Breaking Bad.", "Yo mama is so fat that you have to grease the door frame and hold a twinkie on the other side just to get her through.", "Yo mama is so fat that that when she sits on the beach, Greenpeace shows up and tries to tow her back into the ocean...", "Yo mama is so fat that when she bungee jumps, she brings down the bridge too.", "Yo mama is so fat that when she talks to herself, its a long distance call.", "Yo mama is so fat that the last time she saw 90210, it was on a scale.", "Yo mama is so fat that light bends around her.", "Yo mama is so fat that I took a picture of her last Christmas and it's still printing.","Yo mama is so fat that when she sat on Wal-Mart, she lowered the prices.", "Yo mama is so fat that when she sat on an iphone, it turned into an ipad.", "Yo mama is so fat that even god can't lift her spirit.", "Yo mama is so fat that she gets group insurance.", "Yo mama is so fat that she was zoned for commercial development.", "Yo mama is so fat that she walked into the Gap and filled it.", "Yo mama is so fat that she comes at you from all directions.", "Yo mama is so fat that when she climbed onto a diving board at the beach, the lifeguard told your dad 'sorry, you can't park here'.", "Yo mama is so fat that her cereal bowl came with a lifeguard.", "Yo mama is so fat that she looks like shes smuggling a Volkswagen.", "Yo mama is so fat that when she got her shoes shined, she had to take the guys word for it.", "Yo mama is so fat that when she sings, its over for everybody.", "Yo mama is so fat that when she ran away, they had to use all four sides of the milk carton to display her picture.", "Yo mama is so fat that when she was growing up she didnt play with dolls, she played with midgets.", "Yo mama is so fat that she uses two buses for roller-blades.", "Yo mama's so fat she blew up the Deathstar.", "Yo mama is so fat that when she goes to a buffet, she gets the group rate.", "Yo mama is so fat that she has to put her belt on with a boomerang.", "Yo mama is so fat that she broke the Stairway to Heaven.", "Yo mama is so fat that she doesnt eat with a fork, she eats with a forklift.", "Yo mama is so fat that the last time the landlord saw her, he doubled the rent.", "Yo mama is so fat that Weight Watchers wont look at her.", "Yo mama is so fat that the highway patrol made her wear a sign saying 'Caution. Wide Turn'.", "Yo mama is so fat that when she sits around the house, she SITS AROUND THE HOUSE.","Yo mama is so fat that when she steps on a scale, it reads 'one at a time, please'.", "Yo mama is so fat that she fell in love and broke it.", "Yo mama is so fat that when she gets on the scale it says 'We don't do livestock'.", "Yo mama is so fat that when she tripped on 4th Ave, she landed on 12th.", "Yo mama is so fat that God couldn't light the Earth until she moved.","Yo mama is so fat that even Bill Gates couldn't pay for her liposuction.","Yo mama is so fat that she has to pull down her pants to get into her pockets.", "Yo mama is so fat that she was born on the fourth, fifth, and sixth of June.", "Yo mama is so fat that she could fall down and wouldnt even know it.", "Yo mama is so fat that the sign inside one restaurant says, 'Maximum occupancy: 300, or Yo momma.", "Yo mama is so fat that she puts mayonnaise on aspirin.", "Yo mama is so fat that she was born with a silver shovel in her mouth.", "Yo mama is so fat that when she hauls ass, she has to make two trips.", "Yo mama is so fat that she had to go to Sea World to get baptized.", "Yo mama is so fat that her bellybuttont got an echo.", "Yo mama is so fat that when she turns around people throw her a welcome back party.", "Yo mama is so fat that her belly button doesnt have lint, it has sweaters.", "Yo mama is so fat that a picture of her would fall off the wall.", "Yo mama is so fat that when she takes a shower, her feet dont get wet.", "Yo mama is so fat that she puts on her lipstick with a paint-roller.","Yo mama is so fat that she could sell shade.", "Yo mama is so fat that I ran around her twice and got lost.", "Yo mama is so fat that the shadow of her butt weighs 100 pounds.", "Yo mama is so fat that when shet standing on the corner police drive by and yell, 'Hey, break it up.'","Yo mama is so fat that her blood type is Ragu.", "Yo mama is so fat that when she runs the fifty-yard dash she needs an overnight bag.", "Yo mama is so fat that she cant even fit into an AOL chat room.", "Yo mama is so fat when she goes skydiving she doesn't use a parachute to land, she uses a twin-engine plane.","Yo mama is so fat MTX audio's subwoofers couldn't rattle her bones.","Yo mama is so fat her headphones are a pair of PA speakers connected to a car amplifier.", "Yo mama is so fat that she doesnt have a tailor, she has a contractor.", "Yo mama is so fat that eating contests have banned her because she is unfair competition.", "Yo mama is so fat that she measures 36-24-36, and the other arm is just as big.", "Yo mama is so fat that she gets her toenails painted at Luckyt Auto Body.", "Yo mama is so fat that when she goes to an amusement park, people try to ride HER.","Yo mama is so fat that when she jumps up in the air she gets stuck.","Yo mama is so fat that she has more Chins than a Chinese phone book.","Yo mama is so fat that she influences the tides.", "Yo mama is so fat that when she plays hopscotch, she goes 'New York, L.A., Chicago...'"]))

def check_folders():
    if not os.path.exists(DIR_DATA):
        print("Creating data/oboobs folder...")
        os.makedirs(DIR_DATA)

def check_files():
    settings = {"nsfw_channels": ["133251234164375552"], "nsfw_msg": True}# Red's testing chan. nsfw content off by default.

    if not fileIO(SETTINGS, "check"):
        print("Creating settings.json")
        fileIO(SETTINGS, "save", settings)

def setup(bot):
    check_folders()
    check_files()
    bot.add_cog(oboobs(bot))


